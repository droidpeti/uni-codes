#include <stdio.h>

int main(){
    int i = 0;
    int j = 0;
    printf("i = %d\nj = %d\n", i++, ++j);
    return 0;
}